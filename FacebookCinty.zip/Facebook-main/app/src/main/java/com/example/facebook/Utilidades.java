package com.example.recicler;

public class Utilidades {

    public static int rotacion=0;
    public static boolean validaPantalla=true;

}