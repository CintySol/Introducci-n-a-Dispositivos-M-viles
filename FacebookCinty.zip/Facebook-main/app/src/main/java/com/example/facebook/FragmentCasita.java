package com.example.facebook;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentCasita#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentCasita extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    RecyclerView recyclerCasita;
    ArrayList<CasitaVo> listaCasita;

    public FragmentCasita() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentCasita.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentCasita newInstance(String param1, String param2) {
        FragmentCasita fragment = new FragmentCasita();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View vista=inflater.inflate(R.layout.fragment_casita, container, false);

        listaCasita=new ArrayList<>();
        recyclerCasita= (RecyclerView) vista.findViewById(R.id.casitalist);
        recyclerCasita.setLayoutManager(new LinearLayoutManager(getContext()));

        llenarLista();

        CasitaAdapter adapter=new CasitaAdapter(listaCasita);
        recyclerCasita.setAdapter(adapter);

        return vista;
    }

    private void llenarLista() {
        listaCasita.add(new CasitaVo("Chris Evans",
                "Muy enamorado de Cinty♥",
                R.drawable.minovio,
                R.drawable.publicacion1,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));

        listaCasita.add(new CasitaVo("Jenn Garcia",
                "No gfa, no entre ahi!!",
                R.drawable.jenn,
                R.drawable.publicacion2,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));
        listaCasita.add(new CasitaVo("Remi el Gato",
                "Mi avenger favorito",
                R.drawable.gato,
                R.drawable.publicacion3,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));
        listaCasita.add(new CasitaVo("Cintia Solano",
                "Me les caso banda!! Eres el mejor @Chris Evans. Te amo",
                R.drawable.fotocin,
                R.drawable.publicacion6,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));
        listaCasita.add(new CasitaVo("Ale Jazz",
                "Voy a ser dama de honor! ;D",
                R.drawable.jazz,
                R.drawable.publicacion5,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));

        listaCasita.add(new CasitaVo("Chris Evans",
                "El padrino de boda y mi mejor amigo",
                R.drawable.minovio,
                R.drawable.publicacion4,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));
        listaCasita.add(new CasitaVo("Harry Potter",
                "Se confirma el pastel de bodas de @Chris Evans y @Cintia Solano, en hora buena!",
                R.drawable.harry,
                R.drawable.publicacion7,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));
        listaCasita.add(new CasitaVo("Harry Potter",
                "El trio de oro",
                R.drawable.harry,
                R.drawable.publicacion8,
                R.drawable.likeicon,
                R.drawable.iconcoment,
                R.drawable.compartiricon));

    }


}